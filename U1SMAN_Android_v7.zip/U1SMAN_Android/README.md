# 📱 U1SMAN Android Worker App — v7

Yeh Android app directly Python bot ke saath kaam karta hai.
Firebase RTDB pe SSE stream se instant SMS commands leta hai aur phone se SMS bhejta hai.

---

## ⚡ Bot ↔ Android Flow

```
Telegram Bot (bot.py)
    │
    ▼  PUT clients/{deviceId}/webhookEvent/sendSms
Firebase RTDB
    │
    ▼  SSE Stream (instant detection)
Android App (SmsWorkerService)
    │
    ▼  SmsManager.sendTextMessage()
Real SMS sent!
    │
    ▼  PATCH isSended=true
Firebase RTDB
    │
    ▼  Bot's wait_for_sent() detects it → next SMS
```

---

## 🚀 Android Studio mein build karo

### Step 1 — Open karo
```
File → Open → U1SMAN_Android folder select karo
```

### Step 2 — Sync karo
- Gradle sync automatically hoga
- Agar na ho: **File → Sync Project with Gradle Files**

### Step 3 — Build karo
```
Build → Generate Signed Bundle / APK → APK → Debug
```
Ya seedha phone connect karke Run button dabao.

---

## 📲 App Setup (Phone pe)

1. **APK install karo** (phone pe unknown sources allow karo)
2. **App open karo** — permissions allow karo:
   - ✅ Send SMS (MUST)
   - ✅ Read Phone State
   - ✅ Notifications
3. **Firebase URL set karo** — 🔥 Set Firebase URL button
   - Same URL jo bot mein add kiya hai
   - Example: `https://your-project-rtdb.firebaseio.com`
4. **Device Name set karo** — bot ke /devices mein yahi dikhega
5. **Worker toggle ON karo** — 🟢 Online ho jayega

---

## ⚙️ Settings

| Setting | Default | Kya karta hai |
|---------|---------|---------------|
| Firebase URL | — | RTDB URL (bot wali same) |
| Device Name | Phone model | Bot ke devices list mein naam |
| SIM Slot | SIM 1 | Kaunse SIM se SMS bheje |
| SMS Delay | 2s | SMS ke beech wait (bot ki delay se match karo) |

---

## 🔧 Bot ke saath sync

Bot mein jo `/devices` dikhata hai:
- **modelName** = Device Name + phone model
- **battery** = real-time battery %
- **sims** = SIM info (carrier, slot, number)
- **status** = true (online) / false (offline)

Bot jab campaign chalata hai:
- `from` field = SIM slot (0 ya 1)
- `isSended` = false → app isko detect karta hai
- App SMS bhejta hai → `isSended = true` karta hai
- Bot wait karta hai is change ka → next SMS bhejta hai

---

## 📌 Important Notes

- **Battery optimization disable karo** — app automatically popup dikhata hai
- **Background restriction hatao** — Settings → Apps → U1SMAN → Battery → Unrestricted
- **Reboot ke baad auto-start** — agar worker ON tha to phone restart pe bhi start ho jayega
- **Multiple phones** — sab phones pe same Firebase URL — bot sab mein distribute karega

---

## 🛠️ Troubleshooting

| Problem | Solution |
|---------|----------|
| Status "Reconnecting" bar bar | Internet check karo, Firebase URL sahi hai? |
| SMS nahi ja rahe | SMS permission check karo |
| Bot mein device nahi dikh raha | Firebase URL same hai? Worker ON hai? |
| App band ho jata hai | Battery optimization disable karo |

---

## 📁 Project Structure

```
U1SMAN_Android/
├── app/src/main/
│   ├── AndroidManifest.xml       ← Permissions + components
│   └── java/com/u1sman/smsworker/
│       ├── MainActivity.java      ← UI
│       ├── SmsWorkerService.java  ← Core foreground service (SSE + SMS)
│       ├── FirebaseRestClient.java ← Firebase REST + SSE client
│       ├── DeviceManager.java     ← Device info + SIM details
│       ├── AppPrefs.java          ← Settings storage
│       ├── BootReceiver.java      ← Auto-start on reboot
│       ├── SmsSentReceiver.java   ← SMS sent callback
│       └── SmsDeliveredReceiver.java ← SMS delivered callback
```
