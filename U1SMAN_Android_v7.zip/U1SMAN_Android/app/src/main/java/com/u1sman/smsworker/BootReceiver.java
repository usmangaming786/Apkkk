package com.u1sman.smsworker;

import android.content.*;
import android.os.Build;

/**
 * Auto-restart worker after phone reboot if it was active before.
 */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        String action = intent == null ? "" : intent.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(action)
                && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) return;

        AppPrefs prefs = new AppPrefs(ctx);
        if (!prefs.isWorkerActive()) return;  // User had stopped it, don't restart

        if (!prefs.getFirebaseUrl().isEmpty()) {
            Intent svc = new Intent(ctx, SmsWorkerService.class);
            svc.setAction(SmsWorkerService.ACTION_START);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(svc);
            } else {
                ctx.startService(svc);
            }
        }
    }
}
