package com.u1sman.smsworker;

import android.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    private static final int PERM_REQUEST = 100;

    private AppPrefs prefs;
    private DeviceManager deviceManager;

    // UI views
    private TextView tvStatus, tvDeviceId, tvFirebaseUrl, tvStats, tvLastSms;
    private Switch swWorker;
    private Button btnSetFirebase, btnSetDeviceName, btnSetSim, btnSetDelay, btnResetStats;
    private View statusDot;

    // BroadcastReceiver for service updates
    private final BroadcastReceiver statusReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context ctx, Intent intent) {
            if (SmsWorkerService.BROADCAST_STATUS.equals(intent.getAction())) {
                String status = intent.getStringExtra("status");
                int sent   = intent.getIntExtra("sent", 0);
                int failed = intent.getIntExtra("failed", 0);
                runOnUiThread(() -> updateStatusUI(status, sent, failed));
            } else if (SmsWorkerService.BROADCAST_SMS_SENT.equals(intent.getAction())) {
                String number  = intent.getStringExtra("number");
                boolean success = intent.getBooleanExtra("success", false);
                runOnUiThread(() -> updateLastSms(number, success));
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = new AppPrefs(this);
        deviceManager = new DeviceManager(this);

        bindViews();
        setupListeners();
        refreshUI();
        requestPermissions();
        disableBatteryOptimization();
    }

    private void bindViews() {
        tvStatus       = findViewById(R.id.tvStatus);
        tvDeviceId     = findViewById(R.id.tvDeviceId);
        tvFirebaseUrl  = findViewById(R.id.tvFirebaseUrl);
        tvStats        = findViewById(R.id.tvStats);
        tvLastSms      = findViewById(R.id.tvLastSms);
        swWorker       = findViewById(R.id.swWorker);
        btnSetFirebase  = findViewById(R.id.btnSetFirebase);
        btnSetDeviceName= findViewById(R.id.btnSetDeviceName);
        btnSetSim       = findViewById(R.id.btnSetSim);
        btnSetDelay     = findViewById(R.id.btnSetDelay);
        btnResetStats   = findViewById(R.id.btnResetStats);
        statusDot       = findViewById(R.id.statusDot);
    }

    private void setupListeners() {
        swWorker.setOnCheckedChangeListener((btn, checked) -> {
            if (checked) startWorker();
            else stopWorker();
        });

        btnSetFirebase.setOnClickListener(v -> showInputDialog(
                "Firebase URL", "Enter Firebase RTDB URL",
                prefs.getFirebaseUrl(), InputType.TYPE_CLASS_TEXT,
                url -> {
                    prefs.setFirebaseUrl(url.trim());
                    refreshUI();
                    Toast.makeText(this, "✅ Firebase URL saved", Toast.LENGTH_SHORT).show();
                }
        ));

        btnSetDeviceName.setOnClickListener(v -> showInputDialog(
                "Device Name", "Enter a name for this device\n(shown in bot's /devices)",
                prefs.getDeviceName(), InputType.TYPE_CLASS_TEXT,
                name -> {
                    prefs.setDeviceName(name.trim());
                    refreshUI();
                }
        ));

        btnSetSim.setOnClickListener(v -> {
            String[] options = {"SIM 1 (Slot 0)", "SIM 2 (Slot 1)"};
            new AlertDialog.Builder(this)
                    .setTitle("Select Default SIM Slot")
                    .setSingleChoiceItems(options, prefs.getSimSlot(), (dialog, which) -> {
                        prefs.setSimSlot(which);
                        dialog.dismiss();
                        refreshUI();
                        Toast.makeText(this, "SIM " + (which + 1) + " selected", Toast.LENGTH_SHORT).show();
                    })
                    .show();
        });

        btnSetDelay.setOnClickListener(v -> {
            String[] options = {"0s (Max Speed)", "1s", "2s (Recommended)", "5s (Safe)"};
            float[] delays   = {0f, 1f, 2f, 5f};
            int cur = 2;
            float curDelay = prefs.getSmsDelay();
            for (int i = 0; i < delays.length; i++) {
                if (Math.abs(delays[i] - curDelay) < 0.01f) { cur = i; break; }
            }
            final int current = cur;
            new AlertDialog.Builder(this)
                    .setTitle("SMS Delay Between Sends")
                    .setSingleChoiceItems(options, current, (dialog, which) -> {
                        prefs.setSmsDelay(delays[which]);
                        dialog.dismiss();
                        refreshUI();
                    })
                    .show();
        });

        btnResetStats.setOnClickListener(v -> {
            prefs.resetStats();
            refreshUI();
            Toast.makeText(this, "Stats reset", Toast.LENGTH_SHORT).show();
        });
    }

    private void startWorker() {
        if (prefs.getFirebaseUrl().isEmpty()) {
            Toast.makeText(this, "⚠️ Set Firebase URL first!", Toast.LENGTH_LONG).show();
            swWorker.setChecked(false);
            return;
        }
        if (!hasSmsPermission()) {
            Toast.makeText(this, "⚠️ SMS permission required!", Toast.LENGTH_LONG).show();
            swWorker.setChecked(false);
            requestPermissions();
            return;
        }
        Intent intent = new Intent(this, SmsWorkerService.class);
        intent.setAction(SmsWorkerService.ACTION_START);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
        tvStatus.setText("🟡 Starting…");
    }

    private void stopWorker() {
        Intent intent = new Intent(this, SmsWorkerService.class);
        intent.setAction(SmsWorkerService.ACTION_STOP);
        startService(intent);
        tvStatus.setText("⚫ Offline");
        statusDot.setBackgroundColor(0xFF888888);
    }

    private void refreshUI() {
        String fbUrl = prefs.getFirebaseUrl();
        tvDeviceId.setText("Device ID: " + prefs.getDeviceId());
        tvFirebaseUrl.setText(fbUrl.isEmpty() ? "⚠️ Firebase URL not set" :
                "🔥 " + (fbUrl.length() > 40 ? "…" + fbUrl.substring(fbUrl.length() - 30) : fbUrl));
        tvStats.setText("✅ Sent: " + prefs.getTotalSent() +
                "   ❌ Failed: " + prefs.getTotalFailed() +
                "\n📱 Device: " + prefs.getDeviceName() +
                "\n📡 SIM: " + (prefs.getSimSlot() == 0 ? "SIM 1" : "SIM 2") +
                "   ⏱ Delay: " + prefs.getSmsDelay() + "s");

        boolean active = prefs.isWorkerActive();
        swWorker.setChecked(active);
        if (!active) {
            tvStatus.setText("⚫ Offline");
            statusDot.setBackgroundColor(0xFF888888);
        }
    }

    private void updateStatusUI(String status, int sent, int failed) {
        switch (status) {
            case "online":
                tvStatus.setText("🟢 Online — Listening Firebase");
                statusDot.setBackgroundColor(0xFF4CAF50);
                break;
            case "reconnecting":
                tvStatus.setText("🟡 Reconnecting…");
                statusDot.setBackgroundColor(0xFFFF9800);
                break;
            case "offline":
                tvStatus.setText("⚫ Offline");
                statusDot.setBackgroundColor(0xFF888888);
                swWorker.setChecked(false);
                break;
            default:
                tvStatus.setText("⚪ " + status);
        }
        tvStats.setText("✅ Sent: " + prefs.getTotalSent() +
                "   ❌ Failed: " + prefs.getTotalFailed() +
                "\n📱 Device: " + prefs.getDeviceName() +
                "\n📡 SIM: " + (prefs.getSimSlot() == 0 ? "SIM 1" : "SIM 2") +
                "   ⏱ Delay: " + prefs.getSmsDelay() + "s");
    }

    private void updateLastSms(String number, boolean success) {
        String icon = success ? "✅" : "❌";
        tvLastSms.setText("Last: " + icon + " " + number);
    }

    // ── Input dialog helper ───────────────────────────────────────────────────
    interface StringCallback { void onInput(String value); }

    private void showInputDialog(String title, String hint, String current,
                                  int inputType, StringCallback cb) {
        EditText et = new EditText(this);
        et.setInputType(inputType);
        et.setText(current);
        et.setSelectAllOnFocus(true);
        et.setHint(hint);
        int pad = (int)(16 * getResources().getDisplayMetrics().density);
        et.setPadding(pad, pad, pad, pad);
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(et)
                .setPositiveButton("Save", (d, w) -> {
                    String val = et.getText().toString().trim();
                    if (!val.isEmpty()) cb.onInput(val);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ── Permissions ───────────────────────────────────────────────────────────
    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermissions() {
        List<String> needed = new ArrayList<>();
        String[] perms = {
                Manifest.permission.SEND_SMS,
                Manifest.permission.READ_SMS,
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.READ_PHONE_NUMBERS,
        };
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        for (String p : perms) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED)
                needed.add(p);
        }
        if (!needed.isEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toArray(new String[0]), PERM_REQUEST);
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, @NonNull String[] perms,
                                            @NonNull int[] results) {
        super.onRequestPermissionsResult(req, perms, results);
        if (req == PERM_REQUEST) {
            boolean smsOk = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED;
            if (!smsOk) {
                Toast.makeText(this, "⚠️ SMS permission required to send messages!",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    private void disableBatteryOptimization() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                try {
                    Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                    i.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                } catch (Exception ignored) {}
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter();
        filter.addAction(SmsWorkerService.BROADCAST_STATUS);
        filter.addAction(SmsWorkerService.BROADCAST_SMS_SENT);
        registerReceiver(statusReceiver, filter);
        refreshUI();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try { unregisterReceiver(statusReceiver); } catch (Exception ignored) {}
    }
}
