package com.u1sman.smsworker;

import android.util.Log;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;
import okhttp3.*;

/**
 * Firebase REST client — mirrors Python bot's FirebaseManager exactly.
 * Uses OkHttp with connection pooling (same as Python requests.Session).
 * SSE stream listener for instant isSended detection.
 */
public class FirebaseRestClient {
    private static final String TAG = "FirebaseRestClient";
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    private final String baseUrl;
    private final OkHttpClient restClient;
    private final OkHttpClient sseClient;

    public FirebaseRestClient(String baseUrl) {
        String url = baseUrl.trim().replaceAll("/+$", "");
        if (!url.isEmpty() && !url.startsWith("http")) {
            url = "https://" + url;
        }
        this.baseUrl = url;

        // Short REST calls — connection pooling like Python requests.Session
        this.restClient = new OkHttpClient.Builder()
                .connectTimeout(8, TimeUnit.SECONDS)
                .readTimeout(12, TimeUnit.SECONDS)
                .writeTimeout(8, TimeUnit.SECONDS)
                .connectionPool(new ConnectionPool(20, 5, TimeUnit.MINUTES))
                .retryOnConnectionFailure(true)
                .build();

        // Dedicated SSE client — longer read timeout for streaming
        this.sseClient = new OkHttpClient.Builder()
                .connectTimeout(5, TimeUnit.SECONDS)
                .readTimeout(35, TimeUnit.SECONDS)  // > SMS_WAIT_TIMEOUT=30
                .connectionPool(new ConnectionPool(10, 5, TimeUnit.MINUTES))
                .build();
    }

    private String url(String path) {
        return baseUrl + "/" + path.replaceAll("^/+", "") + ".json";
    }

    // ── Connection test ─────────────────────────────────────────────────────
    public boolean testConnection() {
        try {
            Request req = new Request.Builder()
                    .url(baseUrl + "/.json?shallow=true")
                    .get().build();
            try (Response resp = restClient.newCall(req).execute()) {
                return resp.code() == 200;
            }
        } catch (Exception e) {
            Log.e(TAG, "testConnection: " + e.getMessage());
            return false;
        }
    }

    // ── PUT device online status ─────────────────────────────────────────────
    public boolean putDeviceOnline(String deviceId, JSONObject data) {
        try {
            RequestBody body = RequestBody.create(data.toString(), JSON);
            Request req = new Request.Builder()
                    .url(url("clients/" + deviceId))
                    .put(body).build();
            try (Response resp = restClient.newCall(req).execute()) {
                return resp.code() == 200;
            }
        } catch (Exception e) {
            Log.e(TAG, "putDeviceOnline: " + e.getMessage());
            return false;
        }
    }

    // ── PATCH partial update ─────────────────────────────────────────────────
    public boolean patchDevice(String deviceId, JSONObject data) {
        try {
            RequestBody body = RequestBody.create(data.toString(), JSON);
            Request req = new Request.Builder()
                    .url(url("clients/" + deviceId))
                    .patch(body).build();
            try (Response resp = restClient.newCall(req).execute()) {
                return resp.code() == 200;
            }
        } catch (Exception e) {
            Log.e(TAG, "patchDevice: " + e.getMessage());
            return false;
        }
    }

    // ── Read sendSms command ─────────────────────────────────────────────────
    public JSONObject getSmsCommand(String deviceId) {
        try {
            Request req = new Request.Builder()
                    .url(url("clients/" + deviceId + "/webhookEvent/sendSms"))
                    .get().build();
            try (Response resp = restClient.newCall(req).execute()) {
                if (resp.code() == 200 && resp.body() != null) {
                    String bodyStr = resp.body().string();
                    if (bodyStr.equals("null") || bodyStr.isEmpty()) return null;
                    return new JSONObject(bodyStr);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "getSmsCommand: " + e.getMessage());
        }
        return null;
    }

    // ── Mark isSended = true (bot detects this and clears) ───────────────────
    public boolean markSendSmsTrue(String deviceId) {
        try {
            JSONObject patch = new JSONObject();
            patch.put("isSended", true);
            RequestBody body = RequestBody.create(patch.toString(), JSON);
            Request req = new Request.Builder()
                    .url(url("clients/" + deviceId + "/webhookEvent/sendSms"))
                    .patch(body).build();
            try (Response resp = restClient.newCall(req).execute()) {
                return resp.code() == 200;
            }
        } catch (Exception e) {
            Log.e(TAG, "markSendSmsTrue: " + e.getMessage());
            return false;
        }
    }

    // ── SSE listener — instant command detection ─────────────────────────────
    public interface SseCommandListener {
        /** Called when a sendSms command arrives with isSended=false */
        void onSmsCommand(JSONObject command);
        /** Called when SSE stream breaks — caller should reconnect */
        void onStreamError(Exception e);
    }

    /**
     * Start SSE stream on clients/{deviceId}/webhookEvent/sendSms node.
     * Runs BLOCKING — call from a background thread.
     * Returns when the stream ends or stop() is called.
     */
    public void listenSmsCommands(String deviceId, SseCommandListener listener,
                                   java.util.concurrent.atomic.AtomicBoolean stopFlag) {
        Request req = new Request.Builder()
                .url(url("clients/" + deviceId + "/webhookEvent/sendSms"))
                .header("Accept", "text/event-stream")
                .header("Cache-Control", "no-cache")
                .get().build();
        try {
            try (Response resp = sseClient.newCall(req).execute()) {
                if (resp.code() != 200 || resp.body() == null) {
                    listener.onStreamError(new Exception("SSE HTTP " + resp.code()));
                    return;
                }
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(resp.body().byteStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    if (stopFlag != null && stopFlag.get()) break;
                    if (!line.startsWith("data:")) continue;
                    String data = line.substring(5).trim();
                    if (data.equals("null") || data.isEmpty()) continue;
                    try {
                        // Firebase SSE wraps in {"data": ...}
                        JSONObject wrapper = new JSONObject(data);
                        JSONObject payload = wrapper.optJSONObject("data");
                        if (payload == null) {
                            // Sometimes Firebase sends partial field updates
                            // Check the field value directly
                            if (wrapper.has("isSended") && !wrapper.optBoolean("isSended", true)) {
                                listener.onSmsCommand(wrapper);
                            }
                        } else {
                            if (payload.has("isSended") && !payload.optBoolean("isSended", true)) {
                                listener.onSmsCommand(payload);
                            }
                        }
                    } catch (Exception ignored) { }
                }
            }
        } catch (Exception e) {
            listener.onStreamError(e);
        }
    }

    // ── Battery update ────────────────────────────────────────────────────────
    public void updateBattery(String deviceId, int level) {
        try {
            JSONObject patch = new JSONObject();
            patch.put("battery", level);
            RequestBody body = RequestBody.create(patch.toString(), JSON);
            Request req = new Request.Builder()
                    .url(url("clients/" + deviceId))
                    .patch(body).build();
            restClient.newCall(req).execute().close();
        } catch (Exception ignored) { }
    }

    // ── Set device offline ────────────────────────────────────────────────────
    public void setOffline(String deviceId) {
        try {
            JSONObject patch = new JSONObject();
            patch.put("status", false);
            RequestBody body = RequestBody.create(patch.toString(), JSON);
            Request req = new Request.Builder()
                    .url(url("clients/" + deviceId))
                    .patch(body).build();
            restClient.newCall(req).execute().close();
        } catch (Exception ignored) { }
    }

    public String getBaseUrl() { return baseUrl; }
}
