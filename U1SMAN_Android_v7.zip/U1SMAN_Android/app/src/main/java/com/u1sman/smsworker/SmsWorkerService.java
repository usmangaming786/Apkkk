package com.u1sman.smsworker;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.telephony.*;
import android.util.Log;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import org.json.JSONObject;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Foreground service — mirrors Python FirebaseManager.wait_for_sent() logic.
 *
 * Flow:
 *  1. Register device on Firebase (PUT clients/{deviceId})
 *  2. Start SSE stream on sendSms node → instant command detection
 *  3. On command: validate, send SMS, mark isSended=true
 *  4. Heartbeat every 60s (battery + status refresh)
 *  5. SSE break → reconnect with exponential backoff
 */
public class SmsWorkerService extends Service {
    private static final String TAG = "SmsWorkerService";
    public static final String CHANNEL_ID = "u1sman_worker";
    public static final String ACTION_START = "START";
    public static final String ACTION_STOP  = "STOP";

    // Broadcast actions for UI updates
    public static final String BROADCAST_STATUS  = "com.u1sman.STATUS";
    public static final String BROADCAST_SMS_SENT = "com.u1sman.SMS_SENT";

    private AppPrefs prefs;
    private DeviceManager deviceManager;
    private FirebaseRestClient firebaseClient;

    private final AtomicBoolean running = new AtomicBoolean(false);
    private final AtomicBoolean sseStop = new AtomicBoolean(false);

    private ExecutorService sseExecutor;
    private ScheduledExecutorService heartbeatExecutor;
    private ExecutorService smsExecutor;

    // Stats
    private int sessionSent   = 0;
    private int sessionFailed = 0;
    private String lastStatus = "Idle";

    // SMS sent/delivered PendingIntent actions
    public static final String SMS_SENT_ACTION      = "com.u1sman.SMS_SENT_ACT";
    public static final String SMS_DELIVERED_ACTION = "com.u1sman.SMS_DELIVERED_ACT";

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = new AppPrefs(this);
        deviceManager = new DeviceManager(this);
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopWorker();
            return START_NOT_STICKY;
        }
        if (!running.get()) {
            startForeground(1, buildNotification("Starting…"));
            startWorker();
        }
        return START_STICKY;
    }

    // ── Worker start ─────────────────────────────────────────────────────────
    private void startWorker() {
        String fbUrl = prefs.getFirebaseUrl();
        if (fbUrl.isEmpty()) {
            updateNotification("❌ Firebase URL not set");
            broadcastStatus("No Firebase URL configured");
            stopSelf();
            return;
        }

        running.set(true);
        sseStop.set(false);
        prefs.setWorkerActive(true);

        firebaseClient = new FirebaseRestClient(fbUrl);
        smsExecutor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "sms-sender");
            t.setPriority(Thread.MAX_PRIORITY);
            return t;
        });

        // Heartbeat — battery + status every 60s
        heartbeatExecutor = Executors.newSingleThreadScheduledExecutor();
        heartbeatExecutor.scheduleAtFixedRate(this::sendHeartbeat, 0, 60, TimeUnit.SECONDS);

        // SSE listener thread
        sseExecutor = Executors.newSingleThreadExecutor(r -> new Thread(r, "sse-listener"));
        sseExecutor.submit(this::runSseLoop);
    }

    // ── SSE loop with exponential backoff reconnect ──────────────────────────
    private void runSseLoop() {
        String deviceId = deviceManager.getDeviceId();
        int backoff = 1;

        // First: register device on Firebase
        registerDevice(deviceId);

        while (running.get() && !sseStop.get()) {
            updateNotification("🟢 Online — Listening…");
            broadcastStatus("online");

            firebaseClient.listenSmsCommands(deviceId,
                    new FirebaseRestClient.SseCommandListener() {
                        @Override
                        public void onSmsCommand(JSONObject command) {
                            // Reset backoff on successful command
                            handleSmsCommand(deviceId, command);
                        }
                        @Override
                        public void onStreamError(Exception e) {
                            Log.w(TAG, "SSE stream error: " + e.getMessage());
                        }
                    }, sseStop);

            if (!running.get()) break;

            // SSE broke — reconnect with backoff
            Log.w(TAG, "SSE ended, reconnecting in " + backoff + "s");
            updateNotification("⚠️ Reconnecting in " + backoff + "s…");
            broadcastStatus("reconnecting");

            try { Thread.sleep(backoff * 1000L); } catch (InterruptedException e) { break; }
            backoff = Math.min(backoff * 2, 30); // max 30s backoff

            // Re-register to refresh status=true
            registerDevice(deviceId);
        }
    }

    // ── Device registration ──────────────────────────────────────────────────
    private void registerDevice(String deviceId) {
        try {
            JSONObject payload = deviceManager.buildRegistrationPayload();
            // Use device name from prefs as model name prefix
            String name = prefs.getDeviceName();
            payload.put("modelName", name + " (" + Build.MANUFACTURER + " " + Build.MODEL + ")");
            boolean ok = firebaseClient.putDeviceOnline(deviceId, payload);
            Log.i(TAG, "Device registration: " + (ok ? "OK" : "FAILED"));
        } catch (Exception e) {
            Log.e(TAG, "registerDevice: " + e.getMessage());
        }
    }

    // ── Handle incoming SMS command ──────────────────────────────────────────
    private void handleSmsCommand(String deviceId, JSONObject cmd) {
        smsExecutor.submit(() -> {
            String toNumber = null;
            String message  = null;
            int simSlot     = 0;

            try {
                toNumber = cmd.optString("to", "").trim();
                message  = cmd.optString("message", "").trim();
                simSlot  = cmd.optInt("from", prefs.getSimSlot());

                Log.i(TAG, "SMS command → to=" + toNumber + " slot=" + simSlot
                        + " msg_len=" + message.length());

                if (toNumber.isEmpty() || message.isEmpty()) {
                    Log.w(TAG, "Empty to/message, skipping");
                    firebaseClient.markSendSmsTrue(deviceId);
                    return;
                }

                // Send SMS
                boolean sent = sendSms(toNumber, message, simSlot);

                // Mark isSended=true — bot is waiting for this (wait_for_sent)
                firebaseClient.markSendSmsTrue(deviceId);

                if (sent) {
                    sessionSent++;
                    prefs.incrementSent();
                    lastStatus = "✅ Sent → " + toNumber;
                    broadcastSmsSent(toNumber, true);
                } else {
                    sessionFailed++;
                    prefs.incrementFailed();
                    lastStatus = "❌ Failed → " + toNumber;
                    broadcastSmsSent(toNumber, false);
                }

                updateNotification("📨 " + sessionSent + " sent / " + sessionFailed + " failed");

                // Apply SMS delay (matches bot's delay between sends)
                float delay = prefs.getSmsDelay();
                if (delay > 0) {
                    Thread.sleep((long)(delay * 1000));
                }

            } catch (Exception e) {
                Log.e(TAG, "handleSmsCommand error: " + e.getMessage());
                try { firebaseClient.markSendSmsTrue(deviceId); } catch (Exception ignored) {}
            }
        });
    }

    // ── Actual SMS sending via SmsManager ────────────────────────────────────
    private boolean sendSms(String number, String message, int simSlot) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            Log.e(TAG, "SEND_SMS permission not granted!");
            return false;
        }

        try {
            SmsManager smsManager;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                SubscriptionManager sm = (SubscriptionManager)
                        getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
                if (sm != null) {
                    java.util.List<SubscriptionInfo> subs = sm.getActiveSubscriptionInfoList();
                    if (subs != null && simSlot < subs.size()) {
                        int subId = subs.get(simSlot).getSubscriptionId();
                        smsManager = SmsManager.getSmsManagerForSubscriptionId(subId);
                    } else {
                        smsManager = SmsManager.getDefault();
                    }
                } else {
                    smsManager = SmsManager.getDefault();
                }
            } else {
                smsManager = SmsManager.getDefault();
            }

            // Split long messages automatically
            java.util.ArrayList<String> parts = smsManager.divideMessage(message);

            // PendingIntents for sent/delivered tracking
            java.util.ArrayList<PendingIntent> sentIntents = new java.util.ArrayList<>();
            java.util.ArrayList<PendingIntent> deliveryIntents = new java.util.ArrayList<>();

            for (int i = 0; i < parts.size(); i++) {
                Intent sentIntent = new Intent(SMS_SENT_ACTION);
                sentIntent.setPackage(getPackageName());
                int flags = PendingIntent.FLAG_UPDATE_CURRENT;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    flags |= PendingIntent.FLAG_IMMUTABLE;
                }
                sentIntents.add(PendingIntent.getBroadcast(this, 0, sentIntent, flags));

                Intent deliveryIntent = new Intent(SMS_DELIVERED_ACTION);
                deliveryIntent.setPackage(getPackageName());
                deliveryIntents.add(PendingIntent.getBroadcast(this, 0, deliveryIntent, flags));
            }

            if (parts.size() == 1) {
                smsManager.sendTextMessage(number, null, parts.get(0),
                        sentIntents.get(0), deliveryIntents.get(0));
            } else {
                smsManager.sendMultipartTextMessage(number, null, parts, sentIntents, deliveryIntents);
            }

            Log.i(TAG, "SMS dispatched to " + number + " (" + parts.size() + " parts, SIM slot " + simSlot + ")");
            return true;

        } catch (Exception e) {
            Log.e(TAG, "sendSms failed: " + e.getMessage());
            return false;
        }
    }

    // ── Heartbeat ─────────────────────────────────────────────────────────────
    private void sendHeartbeat() {
        if (firebaseClient == null || !running.get()) return;
        try {
            String deviceId = deviceManager.getDeviceId();
            int battery = deviceManager.getBatteryLevel();
            firebaseClient.updateBattery(deviceId, battery);
        } catch (Exception e) {
            Log.w(TAG, "Heartbeat error: " + e.getMessage());
        }
    }

    // ── Stop ─────────────────────────────────────────────────────────────────
    private void stopWorker() {
        running.set(false);
        sseStop.set(true);
        prefs.setWorkerActive(false);

        if (firebaseClient != null) {
            try {
                firebaseClient.setOffline(deviceManager.getDeviceId());
            } catch (Exception ignored) {}
        }

        if (heartbeatExecutor != null) heartbeatExecutor.shutdownNow();
        if (sseExecutor != null)       sseExecutor.shutdownNow();
        if (smsExecutor != null)       smsExecutor.shutdownNow();

        broadcastStatus("offline");
        stopForeground(true);
        stopSelf();
    }

    // ── Notifications ─────────────────────────────────────────────────────────
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "U1SMAN Worker", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("SMS Worker active notification");
            ch.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private Notification buildNotification(String text) {
        Intent stopIntent = new Intent(this, SmsWorkerService.class);
        stopIntent.setAction(ACTION_STOP);
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) piFlags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent stopPi = PendingIntent.getService(this, 0, stopIntent, piFlags);

        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(this, 0, openIntent, piFlags);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("U1SMAN Worker")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setOngoing(true)
                .setContentIntent(openPi)
                .addAction(android.R.drawable.ic_delete, "Stop", stopPi)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private void updateNotification(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(1, buildNotification(text));
    }

    // ── Broadcasts ────────────────────────────────────────────────────────────
    private void broadcastStatus(String status) {
        Intent i = new Intent(BROADCAST_STATUS);
        i.putExtra("status", status);
        i.putExtra("sent", sessionSent);
        i.putExtra("failed", sessionFailed);
        sendBroadcast(i);
    }

    private void broadcastSmsSent(String number, boolean success) {
        Intent i = new Intent(BROADCAST_SMS_SENT);
        i.putExtra("number", number);
        i.putExtra("success", success);
        sendBroadcast(i);
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        stopWorker();
        super.onDestroy();
    }
}
