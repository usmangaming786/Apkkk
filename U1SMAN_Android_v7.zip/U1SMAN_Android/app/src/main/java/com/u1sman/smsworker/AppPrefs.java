package com.u1sman.smsworker;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.UUID;

/**
 * SharedPreferences wrapper — stores Firebase URL, device name, device ID.
 */
public class AppPrefs {
    private static final String PREFS = "u1sman_prefs";
    private static final String KEY_FIREBASE_URL  = "firebase_url";
    private static final String KEY_DEVICE_NAME   = "device_name";
    private static final String KEY_DEVICE_ID     = "device_id";
    private static final String KEY_SIM_SLOT      = "sim_slot";
    private static final String KEY_SMS_DELAY     = "sms_delay";
    private static final String KEY_WORKER_ACTIVE = "worker_active";
    private static final String KEY_TOTAL_SENT    = "total_sent";
    private static final String KEY_TOTAL_FAILED  = "total_failed";

    private final SharedPreferences prefs;

    public AppPrefs(Context ctx) {
        prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    // Firebase URL
    public String getFirebaseUrl()               { return prefs.getString(KEY_FIREBASE_URL, ""); }
    public void setFirebaseUrl(String url)       { prefs.edit().putString(KEY_FIREBASE_URL, url).apply(); }

    // Device Name
    public String getDeviceName()                { return prefs.getString(KEY_DEVICE_NAME, android.os.Build.MODEL); }
    public void setDeviceName(String name)       { prefs.edit().putString(KEY_DEVICE_NAME, name).apply(); }

    // Device ID (auto-generated UUID, persists forever)
    public String getDeviceId() {
        String id = prefs.getString(KEY_DEVICE_ID, null);
        if (id == null) {
            id = "android_" + UUID.randomUUID().toString().replace("-","").substring(0, 12);
            prefs.edit().putString(KEY_DEVICE_ID, id).apply();
        }
        return id;
    }

    // SIM Slot (0 = SIM1, 1 = SIM2)
    public int getSimSlot()                      { return prefs.getInt(KEY_SIM_SLOT, 0); }
    public void setSimSlot(int slot)             { prefs.edit().putInt(KEY_SIM_SLOT, slot).apply(); }

    // SMS Delay (seconds, default 2s matching bot's DEFAULT_SMS_DELAY)
    public float getSmsDelay()                   { return prefs.getFloat(KEY_SMS_DELAY, 2.0f); }
    public void setSmsDelay(float delay)         { prefs.edit().putFloat(KEY_SMS_DELAY, delay).apply(); }

    // Worker active flag
    public boolean isWorkerActive()              { return prefs.getBoolean(KEY_WORKER_ACTIVE, false); }
    public void setWorkerActive(boolean active)  { prefs.edit().putBoolean(KEY_WORKER_ACTIVE, active).apply(); }

    // Stats
    public int getTotalSent()                    { return prefs.getInt(KEY_TOTAL_SENT, 0); }
    public void incrementSent()                  { prefs.edit().putInt(KEY_TOTAL_SENT, getTotalSent() + 1).apply(); }
    public int getTotalFailed()                  { return prefs.getInt(KEY_TOTAL_FAILED, 0); }
    public void incrementFailed()                { prefs.edit().putInt(KEY_TOTAL_FAILED, getTotalFailed() + 1).apply(); }

    public void resetStats() {
        prefs.edit().putInt(KEY_TOTAL_SENT, 0).putInt(KEY_TOTAL_FAILED, 0).apply();
    }
}
