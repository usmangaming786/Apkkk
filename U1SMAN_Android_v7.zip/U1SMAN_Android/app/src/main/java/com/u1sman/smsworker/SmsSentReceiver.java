package com.u1sman.smsworker;

import android.app.Activity;
import android.content.*;
import android.telephony.SmsManager;
import android.util.Log;

public class SmsSentReceiver extends BroadcastReceiver {
    private static final String TAG = "SmsSentReceiver";
    @Override
    public void onReceive(Context ctx, Intent intent) {
        switch (getResultCode()) {
            case Activity.RESULT_OK:
                Log.i(TAG, "SMS sent successfully");
                break;
            case SmsManager.RESULT_ERROR_GENERIC_FAILURE:
                Log.w(TAG, "SMS generic failure");
                break;
            case SmsManager.RESULT_ERROR_NO_SERVICE:
                Log.w(TAG, "SMS no service");
                break;
            case SmsManager.RESULT_ERROR_NULL_PDU:
                Log.w(TAG, "SMS null PDU");
                break;
            case SmsManager.RESULT_ERROR_RADIO_OFF:
                Log.w(TAG, "SMS radio off");
                break;
            default:
                Log.w(TAG, "SMS send result: " + getResultCode());
        }
    }
}
