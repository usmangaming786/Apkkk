package com.u1sman.smsworker;

import android.app.Activity;
import android.content.*;
import android.util.Log;

public class SmsDeliveredReceiver extends BroadcastReceiver {
    private static final String TAG = "SmsDeliveredReceiver";
    @Override
    public void onReceive(Context ctx, Intent intent) {
        if (getResultCode() == Activity.RESULT_OK) {
            Log.i(TAG, "SMS delivered to handset");
        } else {
            Log.w(TAG, "SMS not delivered, code: " + getResultCode());
        }
    }
}
